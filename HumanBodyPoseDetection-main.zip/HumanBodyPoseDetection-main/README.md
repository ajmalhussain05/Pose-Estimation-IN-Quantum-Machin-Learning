# Human Body Pose Detection & Extraction

![pose_detection](https://github.com/datamagic2020/HumanBodyPoseDetection/blob/main/Pose_detection.jpg)

### Install Depedencies
from requirements.txt file

pip install -r requirements.txt

### Full Code explaination
https://youtu.be/0JU3kpYytuQ
